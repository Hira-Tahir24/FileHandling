
#include <iostream>  
#include <fstream>   
using namespace std;
int main() {
  
  ofstream newFile("test.txt");  

  if (newFile.is_open()) {  
    
    newFile << "C++ is a high-level, general-purpose programming language created by Danish computer scientist Bjarne Stroustrup. \n";  
    newFile << "First released in 1985 as an extension of the C programming language, it has since expanded significantly over time. \n";  
    newFile << "Modern C++ currently has object-oriented, generic, and functional features, in addition to facilities for low-level memory manipulation.\n";  
   newFile << "It is almost always implemented in a compiled language.\n"; 
    newFile << "Many vendors provide C++ compilers, including the Free Software Foundation, LLVM, Microsoft, Intel, Embarcadero, Oracle, and IBM."; 

    
    newFile.close();  

    cout << "Text has been written to the file." << endl; 
  } else {
    cout << "Failed to create the file."<<endl;  
  }

  return 0;  
}

