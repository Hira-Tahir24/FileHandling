
#include <iostream>  
#include <fstream>
#include<sstream>
#include <vector>     
#include <algorithm>  
#include <iterator>  
using namespace std;

int main() {
    std::ifstream inputFile("input.txt");
    std::vector<std::string> lines;

    if (inputFile.is_open()) {
        std::string line;
        while (std::getline(inputFile, line)) {
            lines.push_back(line);
        }
        inputFile.close();

        std::sort(lines.begin(), lines.end());

        std::ofstream outputFile("output.txt");
        if (outputFile.is_open()) {
            for (const auto& sortedLine : lines) {
                outputFile << sortedLine << std::endl;
            }
            outputFile.close();
            std::cout << "Lines sorted and saved to output.txt successfully." << std::endl;
        } else {
            std::cerr << "Error opening output file." << std::endl;
        }
    } else {
        std::cerr << "Error opening input file." << std::endl;
    }

    return 0;
}
    