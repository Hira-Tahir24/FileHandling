
#include <iostream>
#include <fstream>
using namespace std;

int main() {
    ifstream myfile("numbers.txt");
    int num, sum = 0, count = 0;

    if (myfile.is_open()) {
        while (myfile >> num) {
            sum += num;
            count++;
        }
        myfile.close();

        if (count == 0) {
            cout << "No numbers found in the file." << endl;
        } else {
            double average = static_cast<double>(sum) / count;
            cout << "The average of the numbers is: " << average << endl;
        }
    } else {
        cout << "Unable to open file" << endl;
    }

    return 0;
}